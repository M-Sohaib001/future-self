import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';

export default function CharacterArchetype({ apiKey, coreDesire, history, onProceed }) {
  const [archetype, setArchetype] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchArchetype = async () => {
      try {
        const API_BASE = import.meta.env.VITE_API_URL || 'http://127.0.0.1:3001';
        const response = await fetch(`${API_BASE}/api/generate-archetype`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ apiKey, coreDesire, history })
        });
        if (response.ok) {
          const data = await response.json();
          setArchetype(data);
        } else {
          throw new Error('The mirror is clouded.');
        }
      } catch (err) {
        setError(err.message);
      } finally {
        setIsLoading(false);
      }
    };
    fetchArchetype();
  }, [apiKey, coreDesire]);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#050508] text-[#c9a84c] flex flex-col items-center justify-center p-6 bg-black">
        <motion.div animate={{ opacity: [0.3, 0.7, 0.3] }} transition={{ duration: 2, repeat: Infinity }}>
          <p className="text-[10px] uppercase tracking-[0.5em]">Searching the Archives of Fiction...</p>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#050508] text-[#c9a84c] font-serif flex flex-col items-center justify-center p-6 lg:p-12 relative overflow-hidden">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-blue-900/10 via-transparent to-transparent blur-3xl pointer-events-none" />
      
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="relative z-10 max-w-2xl w-full bg-black/40 backdrop-blur-2xl border border-[#c9a84c]/20 p-8 md:p-16 shadow-2xl text-center"
      >
        <p className="text-[10px] uppercase tracking-[0.4em] text-[#c9a84c]/60 mb-8 font-sans">Cultural Echo</p>
        
        <motion.h2 
          initial={{ opacity: 0, y: -10 }} 
          animate={{ opacity: 1, y: 0 }} 
          className="text-3xl md:text-5xl font-light mb-2 tracking-wide"
        >
          {archetype?.character}
        </motion.h2>
        <p className="text-zinc-500 uppercase tracking-widest text-xs mb-12 italic">from {archetype?.origin}</p>
        
        <div className="space-y-6 text-zinc-300 leading-relaxed tracking-wide text-lg md:text-xl font-light italic">
          <p>"{archetype?.comparison}"</p>
        </div>

        <div className="mt-12 pt-12 border-t border-[#c9a84c]/10">
          <p className="text-[10px] uppercase tracking-[0.3em] text-[#c9a84c]/40 mb-2">Core Connection</p>
          <p className="text-[#c9a84c] tracking-[0.2em] font-sans uppercase text-sm">{archetype?.trait}</p>
        </div>

        <button
          onClick={onProceed}
          className="mt-16 px-12 py-4 border border-[#c9a84c]/40 hover:bg-[#c9a84c]/10 text-xs uppercase tracking-[0.5em] transition-all"
        >
          Proceed to Timeline Letters
        </button>
      </motion.div>
    </div>
  );
}
