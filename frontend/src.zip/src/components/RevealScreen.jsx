import { motion } from 'framer-motion';
import BackgroundEffects from './BackgroundEffects';

export default function RevealScreen({ coreDesire, onProceedStep2, onProceedStep3 }) {
  return (
    <div className="min-h-screen bg-[#050508] text-[#c9a84c] font-serif flex flex-col items-center justify-center p-4 lg:p-12 relative overflow-hidden">
      <BackgroundEffects />
      
      {/* Dynamic Ambient Breathing Animation */}
      <motion.div 
        animate={{ 
          opacity: [0.08, 0.2, 0.08],
          scale: [0.95, 1.05, 0.95]
        }}
        transition={{ 
          duration: 6, 
          repeat: Infinity,
          ease: "easeInOut"
        }}
        className="absolute inset-0 pointer-events-none bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-[#c9a84c]/30 via-transparent to-transparent blur-[100px] z-0"
      />
      
      <div className="relative z-10 text-center max-w-4xl w-full">
        <h2 className="text-xs tracking-[0.4em] uppercase text-[#c9a84c] mb-6 drop-shadow-md font-bold">Timeline B: The Active Reality</h2>
        <motion.p
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 2, delay: 1 }}
          className="text-xl md:text-2xl tracking-[0.2em] uppercase text-[#c9a84c]/80 mb-8 font-bold"
        >
          The Truth Revealed
        </motion.p>
        
        <motion.h1
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 3, delay: 2 }}
          className="text-4xl md:text-7xl leading-tight font-light"
        >
          What you <i className="italic">really</i> want is <span className="block mt-6 text-[#c9a84c] font-bold drop-shadow-2xl">{coreDesire}.</span>
        </motion.h1>

        <motion.div
           initial={{ opacity: 0 }}
           animate={{ opacity: 1 }}
           transition={{ duration: 2, delay: 6 }}
           className="mt-24 flex justify-center"
        >
          <button 
            onClick={onProceedStep3}
            className="group relative px-12 py-4 bg-transparent border border-[#c9a84c]/40 hover:border-[#c9a84c] transition-all duration-500 overflow-hidden"
          >
            <div className="absolute inset-0 bg-[#c9a84c]/5 translate-y-full group-hover:translate-y-0 transition-transform duration-500" />
            <span className="relative z-10 text-sm tracking-[0.5em] uppercase text-[#c9a84c] group-hover:text-white transition-colors duration-500">
              Talk to Future Self
            </span>
          </button>
        </motion.div>
      </div>
    </div>
  );
}
